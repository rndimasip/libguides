####Daftar Koleksi Yang Sedang Dipinjam
<hr>
Menu ini memberikan informasi tentang koleksi yang sedang dipinjam.
Dalam menu ini dilengkapi juga dengan fasilitas pencarian dengan pendekatan item dan judul bibliografi.
Informasi yang ada dalam menu ini adalah
- Item Code,
- Member ID peminjam,
- Title,
- Loan Date (tanggal pinjam),
- Due Date (tanggal kembali).
