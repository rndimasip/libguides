####Inventario
<hr>
El módulo de inventario es una funcionalidad de SLiMS para ayudar a los bibliotecarios a realizar un inventario. Cuando comienza el proceso de inventario, todos los ejemplares, excepto los que se encuentren prestados (estado = en préstamo) se marcarán como perdidos, y aparecerán en el menú Ejemplares perdidos hasta que a los mismos se les verifique su existencia a través del inventario físico.
