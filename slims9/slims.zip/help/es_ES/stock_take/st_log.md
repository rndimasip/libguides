##Registro del inventario
<hr>
La función de este menú es encontrar registros al realizar el inventario