###Copias de seguridad

Una funcionalidad para respaldar la base de datos de Senayan. Haga clic en Iniciar nueva copia de seguridad y Senayan realizará una copia de seguridad automáticamente. El formato de los archivos creados para dicha copia es .SQL y se nombran de acuerdo a la fecha de creación y al almacenamiento dentro de los archivos del directorio/copia de seguridad.

Nota:
Para hacer esta copia de seguridad, el usuario de la base de datos mysql debe tener el privilegio de BLOQUEAR TABLAS (LOCK TABLES).