####Reservation Menu

This menu is used to view a list of reservations by the members. Item information contained in this menu is: 
- Item Code, 
- Title, 
- Member, 
- Reserve Date.

Note:
Reserve collection is collection that is not in hand/library at that moment and not a self-lent collection.


####Reservas

Este menú se utiliza para ver una lista de las reservas realizadas por los miembros. La información del ejemplar contenida en este menú es:
- Código del ejemplar,
- Título,
- Miembro,
- Fecha de reserva.

Nota:
La colección de reserva es una colección que no está disponible en la biblioteca en ese momento y no es una colección que sea auto-prestada.
