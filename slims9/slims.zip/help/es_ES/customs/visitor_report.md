###Estadísticas de visitantes

Este es un informe que contiene las estadísticas de los visitantes de la biblioteca. Este informe contiene:
- Tipo de miembro, y
- Número de visitas en cada mes en el año especificado.

La selección basada en el informe del año se puede hacer a través del filtro.