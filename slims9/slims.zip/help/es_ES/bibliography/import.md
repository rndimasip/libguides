#### Importar datos
<hr>
El menú Importar datos se utiliza para recuperar datos bibliográficos de aplicaciones SLiMS externas en formato CSV (o de una base de datos que se ha exportado de Senayan en dicho formato), para luego incluirlos en nuestra aplicación.
