#### Importar en MARC
<hr>
Esta función se utiliza para importar archivos de datos MARC con extensión .MRC o .XML. Antes de usar esta función, es necesario que el servidor SLiMS se haya instalado con PEAR, FILE_MARC y Structures_LinkedList. En los servidores que usan Ubuntu Linux, puede usar el siguiente comando:
sudo pear install channel://pear.php.net/Structures_LinkedList-0.2.2  channel://pear.php.net/File_MARC-0.6.2

Más acerca de PEAR <a href = "http://pear.php.net/index.php" target="_blank">click aquí</a>, para saber más sobre FILE_MARC, <a href = "http://pear.php.net/package/File_MARC" target="_blank">click aquí</a>, y sobre Structures_LinkedList <a href = "http://pear.php.net/package/Structures_LinkedList" target="_blank">click aquí</a>