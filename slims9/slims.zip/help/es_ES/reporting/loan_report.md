###Informe de préstamos

Contiene información sobre los préstamos. El mismo consiste en:
- Préstamo total,
- Préstamos basados en GMD,
- Préstamos por tipo de colección,
- Total de transacciones de préstamos,
- La número de transacciones promedio por día,
- Miembros que tienen préstamos,
- Miembros que no tienen préstamos, y
- Total de préstamos vencidos.