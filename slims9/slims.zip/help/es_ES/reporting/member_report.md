###Informe de miembros

Contiene información de la membresía, es decir:
- Total de miembros registrados,
- Total de miembros activos,
- Total de miembros por tipo de miembro,
- Total de miembros que no están activos y una lista de los 10 (diez) miembros más activos.

El informe está disponible en formato .html y se puede imprimir haciendo clic en Descargar informe

A partir de Senayan3-stable14, los tres tipos de informes están equipados con una función de impresión en varios gráficos circulares. Obtendrá este gráfico simplemente haciendo clic en "Mostrar en una gráfica/plotter" que aparecerá en los mencionados tipos de informe (Estadísticas de la colección, Informe de préstamos e Informe de miembros).