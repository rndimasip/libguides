####Importar datos

Este menú se utiliza para recuperar los datos de los miembros de la aplicación desde fuentes externas para incrporarlos al sistema Senayan. El formato de los datos de la importación es CSV.