####Exportar datos

Este menú se utiliza para recuperar los datos de la membresía dentro de la aplicación y exportar dicho resultado como un archivo CSV.
