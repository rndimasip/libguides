###User Groups

A facility to define Groups of Users. In this you can create groupings of your system users and grant read (Read) or Write (Write) permissions for the Senayan modules. Each user can be placed in more than one group.
