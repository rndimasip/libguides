###System Log

This is a menu to view the recorded processes conducted by the Senayan system. Records that are produced list Time, Location (module name), and Message (description). Messages that appear in the System Logs include Who (User/Administrator), conducted what ,and where.

When the Senayan application has been used, it will automatically log the Senayan work and the log size and load will also increase. Therefore, the system log menus, also contains the facility to SAVE LOGS TO FILES. This process will save the existing log, and then we clean the screen with a click on CLEAR LOGS.
