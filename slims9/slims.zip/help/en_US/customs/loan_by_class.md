###Loan by Classification

This is a classification-based lending report. In addition to classes 0-9, the report also makes possible class-based reporting and Non-Decimal Class 2X. Loans can be filtered by:
- Class, 
- Type, and 
- Year.

This feature also provides the facility to create a spreadsheet file download. Files can be obtained by clicking "Export to spreadsheet format".
